plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "nz.prisk.camapsglucosewidget"
    compileSdk = 35
    defaultConfig { applicationId = "nz.prisk.camapsglucosewidget"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
